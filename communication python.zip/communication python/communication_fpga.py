import serial
import logging
import time
import ascon_pcsn

# Configuration du système de log
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("fpga.log"),
        logging.StreamHandler()
    ]
)

class FPGA:
    def __init__(self, port, baud_rate, timeout=1):
        """Initialise la connexion avec la FPGA."""
        self.port = port
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.ser = None
        logging.info(f"FPGA initialisée sur le port {port}, baud rate: {baud_rate}")

    def open_instrument(self):
        """Ouvre la connexion avec la FPGA."""
        try:
            self.ser = serial.Serial(self.port, self.baud_rate, timeout=self.timeout)
            logging.info("Connexion avec la FPGA ouverte avec succès.")
        except serial.SerialException as e:
            logging.error(f"Erreur lors de l'ouverture de la connexion série: {e}")

    def close_instrument(self):
        """Ferme la connexion avec la FPGA."""
        if self.ser:
            self.ser.close()
            logging.info("Connexion fermée avec succès.")

    def send_command(self, command, data=None):
        """Envoie une commande à la FPGA et récupère la réponse."""
        if self.ser and self.ser.is_open:
            msg = command + (data if data else b'')
            logging.debug(f"Envoyé: {msg.hex()}")
            self.ser.write(msg)
            time.sleep(0.1)
            return self.receive_response()

    def receive_response(self):
        """Reçoit la réponse de la FPGA et formate correctement."""
        if self.ser and self.ser.is_open:
            response = b''
            timeout = time.time() + 3  # Timeout de 3 secondes max
            while time.time() < timeout:
                response += self.ser.read(200)
                if response:
                    break
                time.sleep(0.1)  # Petite pause avant de réessayer
            response_clean = response.replace(b'\n', b'').replace(b'\r', b'')
            logging.info(f"Reçu: {response_clean.hex()}")
            return response_clean

    def send_encryption_parameters(self, key, nonce, assoc_data, waveform):
        """Envoie les paramètres de cryptographie à la FPGA."""
        self.send_command(bytes.fromhex("4B"), key)
        self.send_command(bytes.fromhex("4E"), nonce)
        self.send_command(bytes.fromhex("41"), assoc_data)
        self.send_command(bytes.fromhex("57"), waveform)

    def start_encryption(self):
        """Envoie la commande pour demarrer le chiffrement."""
        return self.send_command(bytes.fromhex("47"))

    def get_tag(self):
        """Recupere le tag d'authentification."""
        return self.send_command(bytes.fromhex("54"))

    def get_ciphertext(self):
        """Récupère le texte chiffré."""
        return self.send_command(bytes.fromhex("43"))

if __name__ == "__main__":
    fpga = FPGA(port="COM10", baud_rate=115200, timeout=0.5)
    fpga.open_instrument()

    key = bytes.fromhex("8A55114D1CB6A9A2BE263D4D7AECAAFF")  # 16 octets
    nonce = bytes.fromhex("4ED0EC0B98C529B7C8CDDF37BCD0284A")  # 16 octets
    assoc_data = bytes.fromhex("4120746F20428000")  # 6 octets + padding (sufix: 8000)
    waveform = bytes.fromhex(
        "5A5B5B5A5A5A5A59554E4A4C4F545553515354565758575A5A595756595B5A5554545252504F4F4C4C4D4D4A49444447474644424341403B36383E4449494747464644434243454745444546474A494745484F58697C92AECEEDFFFFE3B47C471600041729363C3F3E40414141403F3F403F3E3B3A3B3E3D3E3C393C41464646454447464A4C4F4C505555524F5155595C5A595A5C5C5B5959575351504F4F53575A5C5A5B5D5E6060615F605F5E5A5857545252800000"
    )

    fpga.send_encryption_parameters(key, nonce, assoc_data, waveform)
    fpga.start_encryption()

    tag = fpga.get_tag()
    ciphertext = fpga.get_ciphertext()

    print(f"Tag: {tag.hex()}")
    print(f"Ciphertext: {ciphertext.hex()}")

    fpga.close_instrument()

    # Traitement des donnees
    tag_clean = tag[:-2]  # Suppression du "OK"
    cipher_clean = ciphertext[:-5]  # Suppression des octets de padding et du "OK"
    print(f"Tag clean: {tag_clean.hex()}")
    print(f"Ciphertext clean: {cipher_clean.hex()}")

    # Combinaison pour le déchiffrement
    cipher_clean = cipher_clean + tag_clean
    print(f"Donnees combinées pour le dechiffrement: {cipher_clean.hex()}")
    dechif = ascon_pcsn.ascon_decrypt(key, nonce, assoc_data[:-2], cipher_clean)
    print(dechif)
