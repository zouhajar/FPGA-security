import serial
import csv
import sys
import pyqtgraph as pg
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PyQt5.QtCore import QTimer
from ascon_pcsn import ascon_encrypt, ascon_decrypt
import numpy as np
from scipy.signal import butter, filtfilt, medfilt

# Filtrage passe-bande pour enlever le bruit et rendre le signal plus réaliste
def bandpass_filter(data, lowcut=0.5, highcut=50.0, fs=500.0, order=5):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    filtered_data = filtfilt(b, a, data)
    return filtered_data

# Filtre passe-haut
def high_pass_filter(data, cutoff=0.5, fs=500.0, order=5):
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='high')
    return filtfilt(b, a, data)

# Filtre passe-bas
def low_pass_filter(data, cutoff=50.0, fs=500.0, order=5):
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='low')
    return filtfilt(b, a, data)

# Filtre médian
def median_filter(data, kernel_size=3):
    return medfilt(data, kernel_size=kernel_size)

class FPGA:
    def __init__(self, port='COM5', baud_rate=115200, timeout=None):
        self.port = port
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.ser = None
    
    def open_instrument(self):
        try:
            self.ser = serial.Serial(
                port=self.port,
                baudrate=self.baud_rate,
                bytesize=8,
                parity='N',
                stopbits=1,
                timeout=self.timeout
            )
            print(f"Port série ouvert : {self.port}")
        except serial.SerialException as e:
            print(f"Erreur lors de l'ouverture du port série : {e}")
    
    def close_instrument(self):
        if self.ser and self.ser.is_open:
            self.ser.close()
            print("Port série fermé")
    
    def read_trames_from_csv(self, csv_filename):
        try:
            trames = []
            with open(csv_filename, newline='', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile)
                for row in reader:
                    if row:
                        trame = ''.join(row).replace(' ', '')
                        trames.append(bytes.fromhex(trame))
            return trames
        except Exception as e:
            print(f"Erreur de lecture du fichier CSV : {e}")
        return []
    
    def encrypt_trame(self, trame, key, nonce, associated_data, variant="Ascon-128"):
        ciphertext = ascon_encrypt(key, nonce, associated_data, trame, variant)
        return ciphertext
    
    def decrypt_trame(self, ciphertext, key, nonce, associated_data, variant="Ascon-128"):
        decrypted_trame = ascon_decrypt(key, nonce, associated_data, ciphertext, variant)
        return decrypted_trame

class TrameVisualizer(QMainWindow):
    def __init__(self, trames, key, nonce, associated_data, fpga):
        super().__init__()
        self.trames = trames
        self.key = key
        self.nonce = nonce
        self.associated_data = associated_data
        self.fpga = fpga
        self.index = 0
        self.max_points = 500
        self.trame_avant_data = np.zeros(self.max_points)
        self.trame_apres_data = np.zeros(self.max_points)

        self.setWindowTitle("Visualisation des Trames ECG")
        self.setGeometry(100, 100, 800, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        self.plot_widget_avant = pg.PlotWidget(title="Trame Avant Chiffrement")
        self.plot_widget_apres = pg.PlotWidget(title="Trame Après Déchiffrement")
        layout.addWidget(self.plot_widget_avant)
        layout.addWidget(self.plot_widget_apres)

        self.plot_widget_avant.setBackground('k')
        self.plot_widget_apres.setBackground('k')

        self.plot_widget_avant.getAxis('bottom').setPen(pg.mkPen('w'))
        self.plot_widget_avant.getAxis('left').setPen(pg.mkPen('w'))
        self.plot_widget_apres.getAxis('bottom').setPen(pg.mkPen('w'))
        self.plot_widget_apres.getAxis('left').setPen(pg.mkPen('w'))

        self.plot_widget_avant.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget_apres.showGrid(x=True, y=True, alpha=0.3)

        self.plot_widget_avant.setYRange(-100, 100)
        self.plot_widget_apres.setYRange(-100, 100)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(20)

    def update_plot(self):
        if self.index >= len(self.trames):
            self.index = 0
        
        trame = self.trames[self.index]
        encrypted_trame = self.fpga.encrypt_trame(trame, self.key, self.nonce, self.associated_data)
        decrypted_trame = self.fpga.decrypt_trame(encrypted_trame, self.key, self.nonce, self.associated_data)

        trame_avant_int = np.array(list(trame), dtype=np.float64)
        decrypted_trame_int = np.array(list(decrypted_trame), dtype=np.float64)

        trame_avant_int -= np.mean(trame_avant_int)
        decrypted_trame_int -= np.mean(decrypted_trame_int)

        # Appliquer plusieurs filtres pour améliorer le réalisme du signal
        trame_avant_filtered = low_pass_filter(high_pass_filter(trame_avant_int))
        trame_apres_filtered = low_pass_filter(high_pass_filter(decrypted_trame_int))

        self.trame_avant_data = np.roll(self.trame_avant_data, -1)
        self.trame_avant_data[-1] = trame_avant_filtered[-1]
        self.trame_apres_data = np.roll(self.trame_apres_data, -1)
        self.trame_apres_data[-1] = trame_apres_filtered[-1]

        self.plot_widget_avant.clear()
        self.plot_widget_avant.plot(self.trame_avant_data, pen=pg.mkPen('r', width=2))
        self.plot_widget_apres.clear()
        self.plot_widget_apres.plot(self.trame_apres_data, pen=pg.mkPen('g', width=2))

        self.index += 1

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    fpga = FPGA(port='COM5', baud_rate=115200, timeout=1)
    fpga.open_instrument()
    
    key = bytes.fromhex("8A55114D1CB6A9A2BE263D4D7AECAAFF")
    nonce = bytes.fromhex("4ED0EC0B98C529B7C8CDDF37BCD0284A")
    associated_data = bytes.fromhex("4120746F20428000")
    
    trames = fpga.read_trames_from_csv('Downloads/waveform_example_ecg.csv')
    
    if trames:
        window = TrameVisualizer(trames, key, nonce, associated_data, fpga)
        window.show()
        sys.exit(app.exec_())
    else:
        print("Aucune trame valide trouvée.")
    
    fpga.close_instrument()
